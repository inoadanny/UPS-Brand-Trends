var express = require('express');
var dashRouter = express.Router();
var mongodb = require('mongodb').MongoClient;
var objectId = require('mongodb').ObjectID;

var router = function (nav) {
	// Implement API here
};
module.exports = router;