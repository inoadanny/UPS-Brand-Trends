var mongodb = require('mongodb').MongoClient;
var objectId = require('mongodb').ObjectID;

var dashController = function (nav) {

    };

    return {
    };
};

module.exports = dashController;